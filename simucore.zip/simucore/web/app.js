const $ = id => document.getElementById(id);
const fields = {load: $('load'), ambient: $('ambient'), cooling: $('cooling')};
let baseline = null, current = null, timer;
const defaults = {load: 72, ambient: 24, cooling: 65};

function setLabels(){ $('loadValue').textContent = fields.load.value+'%'; $('ambientValue').textContent=fields.ambient.value+'°C'; $('coolingValue').textContent=fields.cooling.value+'%'; }
async function fetchModel(){
  clearTimeout(timer);
  const params = new URLSearchParams({load:fields.load.value,ambient:fields.ambient.value,cooling:fields.cooling.value,hours:8});
  try { const r=await fetch('/api/simulate?'+params); current=await r.json(); render(current); }
  catch(e){ $('updated').textContent='Could not reach the local simulator'; }
}
function render(data){
  $('risk').textContent=data.risk; $('temp').textContent=data.peak_temperature.toFixed(1); $('wear').textContent=data.final_damage.toFixed(3);
  const bar=$('riskBar'); bar.style.width=data.risk+'%'; bar.style.background=data.status==='critical'?'#ff6b78':data.status==='warning'?'#ffc36a':'#ad98ff';
  $('riskFoot').textContent=data.status==='normal'?'Low modeled risk over 8 hours':data.status==='warning'?'Elevated modeled risk':'High modeled risk';
  $('updated').textContent='MODEL UPDATED '+new Date(data.updated_at).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit',second:'2-digit'});
  drawChart(data.series,baseline?.series);
  const alerts=[];
  if(data.peak_temperature>=78) alerts.push(['!','Thermal limit exceeded',`Peak reaches ${data.peak_temperature}°C, above the 78°C operating threshold.`,'THERMAL']);
  else if(data.peak_temperature>=70) alerts.push(['!','Temperature approaching limit',`Peak reaches ${data.peak_temperature}°C. Check cooling before increasing load.`,'WATCH']);
  if(data.risk>=35) alerts.push(['!','Elevated failure risk',`Model estimates ${data.risk}% risk over the selected ${data.inputs.hours}-hour window.`,'RISK']);
  if(data.inputs.load>100) alerts.push(['!','Overload condition',`Load is ${data.inputs.load}% of nominal capacity.`,'LOAD']);
  if(!alerts.length) alerts.push(['✓','Operating within modeled range','No thresholds crossed for the current scenario.','NORMAL']);
  $('alertCount').textContent=`${alerts.length} ACTIVE`;
  $('alerts').innerHTML=alerts.map(([icon,title,desc,tag])=>`<div class="alert-row"><div class="alert-icon ${tag==='NORMAL'?'ok':''}">${icon}</div><div><b>${title}</b><p>${desc}</p></div><span class="alert-tag ${tag==='NORMAL'?'ok':''}">${tag}</span></div>`).join('');
  if(baseline){const diff=data.risk-baseline.risk; $('comparison').hidden=false; $('comparison').innerHTML=`Compared with baseline: risk is <b>${Math.abs(diff)} percentage points ${diff>0?'higher':diff<0?'lower':'unchanged'}</b> (${baseline.risk}% → ${data.risk}%).`;}
  timer=setTimeout(fetchModel,4000);
}
function drawChart(series,base){
  const svg=$('chart'), w=760,h=250, left=37,right=8,top=9,bottom=23;
  const all=series.map(p=>p.temperature).concat(base?base.map(p=>p.temperature):[]);
  const min=Math.floor((Math.min(...all)-4)/10)*10,max=Math.ceil((Math.max(...all)+4)/10)*10;
  const x=i=>left+i/(series.length-1)*(w-left-right), y=v=>top+(max-v)/(max-min)*(h-top-bottom);
  let s=''; for(let v=min;v<=max;v+=10)s+=`<line x1="${left}" y1="${y(v)}" x2="${w-right}" y2="${y(v)}" stroke="#303140"/><text x="0" y="${y(v)+3}" fill="#a6a4b8" font-size="9" font-family="DM Mono">${v}°</text>`;
  if(base){const d=base.map((p,i)=>`${i?'L':'M'}${x(i)} ${y(p.temperature)}`).join(' ');s+=`<path d="${d}" fill="none" stroke="#77768b" stroke-width="2" stroke-dasharray="5 5"/>`;}
  const d=series.map((p,i)=>`${i?'L':'M'}${x(i)} ${y(p.temperature)}`).join(' '), area=`${d} L${x(series.length-1)} ${h-bottom} L${x(0)} ${h-bottom} Z`;
  s+=`<path d="${area}" fill="url(#area)"/><defs><linearGradient id="area" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ad98ff" stop-opacity=".14"/><stop offset="1" stop-color="#ad98ff" stop-opacity="0"/></linearGradient></defs><path d="${d}" fill="none" stroke="#ad98ff" stroke-width="2.5"/>`;
  const limitY=y(78); if(limitY>=top&&limitY<=h-bottom)s+=`<line x1="${left}" y1="${limitY}" x2="${w-right}" y2="${limitY}" stroke="#ffc36a" stroke-dasharray="3 4"/><text x="${w-right-85}" y="${limitY-5}" fill="#ffc36a" font-size="9" font-family="DM Mono">78° LIMIT</text>`;
  svg.innerHTML=s;
}
Object.values(fields).forEach(el=>el.addEventListener('input',()=>{setLabels();fetchModel();}));
$('reset').onclick=()=>{Object.entries(defaults).forEach(([k,v])=>fields[k].value=v);baseline=null;$('comparison').hidden=true;setLabels();fetchModel();};
$('compare').onclick=async()=>{const p=new URLSearchParams({load:defaults.load,ambient:defaults.ambient,cooling:defaults.cooling,hours:8});baseline=await(await fetch('/api/simulate?'+p)).json();fetchModel();};
setLabels();fetchModel();
