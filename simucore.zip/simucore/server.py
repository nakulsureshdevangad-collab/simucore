"""SimuCore: a small, model-driven thermal stress simulator for a pump."""
from __future__ import annotations

import json
import math
from datetime import datetime, timezone
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

ROOT = Path(__file__).parent


def simulate(ambient: float = 24, load: float = 72, cooling: float = 65, hours: float = 8):
    """Euler simulation of heat balance and cumulative insulation damage.

    Temperature follows dT/dt = heat input - cooling. Failure risk is a
    calibrated logistic hazard proxy based on thermal limit exceedance and
    cumulative damage. It is a transparent engineering model, not random data.
    """
    dt = 0.1  # hours
    steps = max(1, int(hours / dt))
    temp = ambient + 15
    damage = 0.0
    points = []
    for i in range(steps + 1):
        t = i * dt
        # Load produces heat quadratically; cooling capacity scales linearly.
        heat_gain = 0.07 * (load / 100) ** 2 * 100
        heat_loss = (0.07 + 0.001 * cooling) * (temp - ambient)
        temp += (heat_gain - heat_loss) * dt
        # Accelerated aging: insulation damage doubles for each 10 C over 70 C.
        aging_rate = math.exp(max(-5, (temp - 70) / 10)) / 1000
        damage += aging_rate * dt
        if i % 5 == 0 or i == steps:
            points.append({"hour": round(t, 1), "temperature": round(temp, 1),
                           "damage": round(damage, 4)})

    peak = max(p["temperature"] for p in points)
    # Logistic transform of thermal overage and accumulated aging.
    raw = 0.11 * (peak - 78) + 9 * damage - 0.5
    risk = 100 / (1 + math.exp(-max(-20, min(20, raw))))
    status = "critical" if risk >= 70 else "warning" if risk >= 35 else "normal"
    return {"inputs": {"ambient": ambient, "load": load, "cooling": cooling, "hours": hours},
            "peak_temperature": round(peak, 1), "final_damage": round(damage, 4),
            "risk": round(risk), "status": status, "series": points}


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT / "web"), **kwargs)

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/api/simulate":
            q = parse_qs(parsed.query)
            def number(key, default, low, high):
                try: return max(low, min(high, float(q.get(key, [default])[0])))
                except ValueError: return default
            result = simulate(number("ambient", 24, -10, 45), number("load", 72, 10, 120),
                              number("cooling", 65, 0, 100), number("hours", 8, 1, 24))
            result["updated_at"] = datetime.now(timezone.utc).isoformat()
            payload = json.dumps(result).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return
        if parsed.path == "/": self.path = "/index.html"
        return super().do_GET()


if __name__ == "__main__":
    print("SimuCore running at http://localhost:8000")
    ThreadingHTTPServer(("127.0.0.1", 8000), Handler).serve_forever()
