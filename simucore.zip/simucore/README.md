# SimuCore

SimuCore is a local, physics-based digital-twin demo for exploring pump operating conditions before changing a real system. Adjust load, ambient temperature, and cooling efficiency to see the modeled temperature curve, accumulated wear, failure-risk estimate, and alerts update live.

## Run locally

Requires Python 3.10+; no packages or hardware are needed.

```powershell
python server.py
```

Open <http://localhost:8000> in a browser. Stop the server with Ctrl+C.

## Model

The simulator uses a 0.1-hour Euler time step. Heat input grows with the square of normalized load; heat dissipation grows with cooling efficiency and the temperature difference from ambient. Insulation aging accumulates exponentially above 70°C. A logistic transform of peak temperature and accumulated aging produces the displayed risk score. The default 78°C limit is shown on the chart and drives a warning alert.

This is a transparent illustrative model with synthetic operating conditions, not a trained predictive-maintenance model or a safety-certified engineering tool. Calibrate coefficients and thresholds against equipment-specific measurements before operational use.
